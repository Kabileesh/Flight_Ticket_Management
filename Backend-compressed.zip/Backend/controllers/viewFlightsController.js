const Flight = require("../model/flightModel");

const viewFlights = async (req, res) => {
  /*
code for only comparing time part

const targetTimeStart = new Date('1970-01-01T08:00:00Z');
const targetTimeEnd = new Date('1970-01-01T12:00:00Z');

Flight.aggregate([
  {
    $match: {
      $expr: {
        $and: [
          { $gte: [{ $hour: '$departureTime' }, targetTimeStart.getHours()] },
          { $gte: [{ $minute: '$departureTime' }, targetTimeStart.getMinutes()] },
          { $lte: [{ $hour: '$departureTime' }, targetTimeEnd.getHours()] },
          { $lte: [{ $minute: '$departureTime' }, targetTimeEnd.getMinutes()] },
        ]
      },
      source: source,
      destination: destination,
      availableDays: { $in: [availableDay] }
    }
  }
])
  .then((flights) => {
    console.log(flights);
  })
  .catch((error) => {
    console.error(error);
  });

*/

  try {
    const { selectedDate, selectedTime, source, destination } = req.body;
    const flights = await Flight.aggregate([
        {
          $match: {
            $expr: {
              $and: [
                { $eq: [{ $hour: '$depatureTime' }, new Date(selectedTime).getHours()] },
                { $lte: [{ $minute: '$depatureTime' }, new Date(selectedTime).getMinutes()] },
              ]
            },
            source: source,
            destination: destination,
            availableDays: { $in: [new Date(selectedDate).getDay()] }
          }
        }
      ]);
      console.log(new Date(selectedTime));
    console.log(new Date(selectedTime).getHours());
    console.log(new Date(selectedTime).getMinutes());
    res.send(flights);
  } catch (err) {
    console.log(err);
  }
};

module.exports = viewFlights;

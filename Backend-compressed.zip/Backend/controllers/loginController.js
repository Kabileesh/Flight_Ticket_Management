const passport = require("passport");
const User = require("../model/userModel");

// need to resolve user already exist error

const registerUser = async (req, res) => {
  const newUser = new User({
    name: req.body.name,
    username: req.body.username,
    phone: +req.body.phone,
  });
  try {
    const exisitingUser = await User.find(
      { username: { $eq: newUser.username } },
      { _id: 0 }
    );
    if (exisitingUser.username == req.body.username) {
      return res.status(400).json({ error: "Username alredy Existing" });
    }
    await User.register(newUser, req.body.password).then(() => {
      passport.authenticate("local")(req, res, (next) => {
        res.json({ response: "Render Sign In Page" });
      });
    });
  } catch (err) {
    console.log(err);
  }
};

const loginUser = async (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  if (!username || !password) {
    res.send("Enter valid email id");
  } else {
    const existingUser = await User.findOne({ username: username }, { _id: 0 });
    if (!existingUser) {
      res.send("No user has been found");
    } else if (existingUser.isAdmin == true) {
      passport.authenticate("local")(
        req,
        res,
        (next) => {
          res.send("Admin Login : Successfully Logged in");
        }
        // ,{
        //     // successRedirect : "/home",
        //     // failureRedirect : "/login",
        // }
      );
    } else {
      passport.authenticate("local")(
        req,
        res,
        (next) => {
          res.send("User Login : Successfully Logged in");
        }
        // ,{
        //     // successRedirect : "/home",
        //     // failureRedirect : "/login",
        // }
      );
    }
  }
};

module.exports = {
  registerUser,
  loginUser,
};

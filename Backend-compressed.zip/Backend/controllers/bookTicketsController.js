const Bookings = require("../model/bookingsModel");
const Flight = require("../model/flightModel");
const mongoose = require("mongoose");

const bookTicket = async (req, res) => {
  // if (req.isAuthenticated()) {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      const opts = { session };
      const {
        selectedDate,
        selectedTime,
        source,
        destination,
        flightNumber,
        seatNumber,
      } = req.body;

      const selectedFlight = await Flight.find({
        flightNumber: flightNumber,
        source: source,
        destination: destination,
      });

      const bookedSeats = await Bookings.aggregate([
        {
          $match: {
            $expr: {
              $and: [
                { $eq: [{ $hour: '$depatureTime' }, new Date(selectedTime).getHours()] },
                { $eq: [{ $minute: '$depatureTime' }, new Date(selectedTime).getMinutes()] },
              ]
            },
          flightNumber: flightNumber,
          bookingDate: new Date(selectedDate).toISOString(),
          }
        }],
        { user_id: 0 }
      );

      const newBooking = new Bookings({
        // user_id: req.user.id,
        user_id : req.body.user_id,
        flightNumber: flightNumber,
        seatNumber: seatNumber,
        bookingDate: selectedDate,
        bookingTime: selectedTime,
        totalTicketFair: selectedFlight[0].ticketFair * seatNumber.length,
      });

      await newBooking.save(opts);
      let totalBooked;
      for (let seat in bookedSeats) {
        totalBooked += seat.seatNumber.length;
      }

      const totalSeats = selectedFlight.availableSeats;

      const availableSeats = totalSeats - totalBooked;

      if (availableSeats >= seatNumber.length) {
        throw new Error("No seats available");
      }

      await session.commitTransaction();
      session.endSession();

      res.send("Ticket booked successfully");
    } catch (err) {
      await session.abortTransaction();
      session.endSession();
      console.error("Failed to book ticket:", err);
    }
  // } else {
  //   res.status(401).json("Unauthorized user");
  // }
};

module.exports = bookTicket;

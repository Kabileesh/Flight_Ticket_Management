const Bookings = require("../model/bookingsModel");

const viewBookings = async (req, res) => {
  // need to check for altering of date as ISO Date
  // and also for the time
  const prevBookings = await Bookings.find(
    {
      //user_id: req.user.id,
      user_id: req.body.user_id,
      bookingDate: { $lte: new Date().toISOString() },
      bookingTime: { $lte: new Date().toISOString() },
    },
    { user_id: 0 }
  );
  const currBookings = await Bookings.find(
    {
      // user_id: req.user.id,
      user_id: req.body.user_id,
      bookingDate: { $gt: new Date().toISOString() },
      bookingTime: { $gt: new Date().toISOString() },
    },
    { user_id: 0 }
  );
  res.status(200).json({"previous" : prevBookings, "current": currBookings});
};

module.exports = viewBookings;

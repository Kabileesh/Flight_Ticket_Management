const mongoose = require("mongoose");

const flightSchema = new mongoose.Schema({
  flightNumber: {
    type: Number,
    required: true,
  },
  source : {
    type : String,
    required : true,
  },
  destination : {
    type : String,
    required : true,
  },
  arrivalTime: {
    type: Date,
    required: true,
  },
  depatureTime: {
    type: Date,
    required: true,
  },
  availableDays: {
    type: [Number],
    required: true,
  },
  availableSeats: {
    type: Number,
    required: true,
  },
  ticketFair : {
    type : Number,
    required : true,
  }
});

const Flight = mongoose.model("Flight", flightSchema);

module.exports = Flight;

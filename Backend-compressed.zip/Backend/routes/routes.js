const express = require("express");
const { registerUser, loginUser } = require("../controllers/loginController");
const logOutUser = require("../controllers/logOutController");
const viewFlights = require("../controllers/viewFlightsController");
const bookTicket = require("../controllers/bookTicketsController");
const addFlight = require("../admin/addFlightController");
const removeFlight = require("../admin/deleteFlightController");
const viewBookings = require("../controllers/viewBookingsController");
const router = express.Router();

router.post("/add-flight", addFlight);
router.delete("/remove-flight", removeFlight);

router.get("/view-flights", viewFlights);
router.post("/book-ticket", bookTicket);
router.get("/view-bookings", viewBookings);
router.post("/register", registerUser);
router.post("/login", loginUser);
router.post("/logout", logOutUser);
router.get("/", (req, res) => {
    res.json({ response : "Home Page"})
})

module.exports = router;
const Flight = require("../model/flightModel");
const User = require("../model/userModel");

const removeFlight = async (req, res) => {
  try {
    const user_id = req.user.id;
    const existingUser = await User.findById(user_id, {_id : 0});
    if (req.isAuthenticated() && existingUser.isAdmin) {
      const flightNumber = req.body.FlightNumber;
      Flight.findOneAndDelete(
        { flightNumber: flightNumber },
        (err, removedFlight) => {
          if (err) {
            console.log(err);
          } else {
            res.send(removedFlight, "Flight removed succesfullly");
          }
        }
      );
    }
    else{
        res.status(401).json("Unauthorized User");
    }
  } catch (err) {
    console.log(err);
  }
};


module.exports = removeFlight;
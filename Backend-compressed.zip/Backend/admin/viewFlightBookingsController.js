const Booking = require("../model/bookingsModel");


const viewFlightBookings = async (req, res) => {
    try {
        const user_id = req.user.id;
        const existingUser = await User.findById(user_id, {_id : 0});
        if (req.isAuthenticated() && existingUser.isAdmin) {
            const {flightNumber, selectedTime} = req.body;
            const flightBookings = await Booking.aggregate([
                {
                    $match : {
                        $expr: {
                            $and: [
                                { $eq: [{ $hour: '$arrivalTime' }, new Date(selectedTime).getHours()] },
                                { $eq: [{ $minute: '$arrivalTime' }, new Date(selectedTime).getMinutes()] },
                            ]
                        },
                        flightNumber : flightNumber
                    }
                }
            ]);
            res.send(flightBookings);
        }
        else{
            res.status(401).json("Unauthorized User");
        }
    }catch(err){
        console.log(err);
    }
}
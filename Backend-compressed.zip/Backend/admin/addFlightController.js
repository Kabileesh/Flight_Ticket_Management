const Flight = require("../model/flightModel");

const addFlight = async (req, res) => {
  // const user_id = req.user.id;
  // const existingUser = await User.findById(user_id, {_id : 0});
  // if (req.isAuthenticated() && existingUser.isAdmin) {
    const {
      flightNumber,
      source,
      destination,
      arrivalTime,
      depatureTime,
      availableDays,
      availableSeats,
      ticketFair,
    } = req.body;
    try {
      const newFlight = new Flight({
        flightNumber: flightNumber,
        source: source,
        destination: destination,
        arrivalTime: arrivalTime,
        depatureTime: depatureTime,
        availableDays: availableDays,
        availableSeats : availableSeats,
        ticketFair: ticketFair,
      });
      newFlight.save();
      res.send("New Flight Added successfully");
    } catch (err) {
      console.log(err);
      res.send(err);
    }
  // } else {
  //   res.status(401).json("Unauthorised User");
  // }
};

module.exports = addFlight;
